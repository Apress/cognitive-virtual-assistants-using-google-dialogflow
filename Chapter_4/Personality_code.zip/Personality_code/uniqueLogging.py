import logging
import time
import os

def unique_logging():
	cwd_new = '.'
	unique_logger=logging.getLogger('Personality')
	unique_logger.setLevel(logging.INFO)
	date=time.strftime("%Y_%m_%d")
	fh = logging.FileHandler(str(cwd_new)+"/logs/personality_" + str(date)+".log")
	formatter = logging.Formatter('%(asctime)s - %(name)s - %(funcName)2s - %(levelname)s - %(message)s')
	fh.setFormatter(formatter)
	unique_logger.addHandler(fh)
	return unique_logger
