import json
from flask import request
from flask_classful import FlaskView, route
from models.corpus import PersonalityModel


class EndPointCall(FlaskView):
    @route("/personality", methods=['POST'])
    def endpoint(self):
        """
        Personality
        """
        personalityModel = PersonalityModel('testData')
        json_data = request.get_json(force=True)
        question = json_data["queryResult"]["queryText"]

        answer = personalityModel.getRecommendation("testData", question)
        output = {
            "fulfillmentText": answer,
            "fulfillmentMessages": [{"text": {
                "text": [
                    answer
                ]
            }}],
            "source": "personality-webhook"
        }
        return json.dumps(output)