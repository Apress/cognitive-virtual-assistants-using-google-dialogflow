from collections import defaultdict
import random
import os
import sys

cmd_new = '.'

#sys.path.append(cmd_new + '/')

import fileOperations as fileOp
# import nlpTask as nlp
import uniqueLogging
import time
import difflib
import operator
from random import shuffle
from utils import nlpTask as nlp
from nltk.corpus import wordnet
import nltk
import string
import random
from ConfigParser import SafeConfigParser
import os


config = SafeConfigParser()
config.read(cmd_new + '/config/personalityConfig.cfg')

jaccard_logger = uniqueLogging.unique_logging()


def compare(sentence_1, sentence_2):
    try:
        confidence_score = 0.0
        common_tokens = set(sentence_1).intersection(sentence_2)
        probability_score = 0.0
        if len(common_tokens) == 0:
            return confidence_score
        for token in common_tokens:
            sent_1_token_count = sentence_1.count(token)
            sent_2_token_count = sentence_2.count(token)
            probability_score = probability_score + (sent_1_token_count + sent_2_token_count) / 2
        confidence_score = probability_score / (len(sentence_1) + len(sentence_2) - probability_score)

        # confidence_score = len(set(sentence_1).intersection(sentence_2)) / float(len(set(sentence_1).union(sentence_2)))
        return confidence_score
    except Exception as e:
        jaccard_logger.error('Error while comparing sentences......')
        jaccard_logger.error('Error details.......{}'.format(e))


def find_similar_response(questionList, questionTokenList, answerDict, questionDict, question):
    similarity = []
    summary_list = []
    similarity = {}
    result_tuple = []
    # print questionTokenList
    try:
        for variation in questionList:
            similarity[variation] = compare(question, questionDict[variation])
        result = sorted(similarity.items(), key=operator.itemgetter(1), reverse=True)[:5]
        if result[0][1] > 0.70:
            result_tuple.append((question, random.choice(answerDict[result[0][0]]), result[0][1]))

        else:
            if result[0][1] == 0:
                result_tuple.append((question, config.get('RESPONSES', 'NO_RESULT'), result[0][1]))
            else:
                similarity = {}
                questionResponse = {}
                for resultIndex in range(len(result)):
                    keys = similarity.keys()
                    max_score = 0.0
                    response = random.choice(answerDict[result[resultIndex][0]])
                    question = result[resultIndex][0]
                    score = result[resultIndex][1]
                    if response not in keys:
                        similarity[response] = score
                        questionResponse[question] = score
                    else:
                        if score > max_score:
                            similarity[response] = score
                            questionResponse[question] = score
                            max_score = score
                similarity = sorted(similarity.items(), key=operator.itemgetter(1), reverse=True)
                questionResponse = sorted(questionResponse.items(), key=operator.itemgetter(1), reverse=True)
                print "dicstionary", questionResponse
                for result in similarity:
                    result_tuple.append((question, result[0], result[1]))
                '''print result
                print result
                for resultIndex in range(len(result)):
                                    result_tuple.append((question,random.choice(answerDict[result[resultIndex][0]]), result[resultIndex][1]))'''

        similarity = {}
        summary_list = []
        return result_tuple

    except Exception, e:
        unique_logger.error('Exception Occured.........')
        unique_logger.error('Exception Details........%s', e)


if __name__ == '__main__':
    try:
        tin = time.time()
        question_filename = 'personality_question.pkl'
        answer_filename = 'personality_answer.pkl'
        question_dict = fileOp.read_pickle_file(question_filename)
        answer_dict = fileOp.read_pickle_file(answer_filename)
        while True:
            question = raw_input('Enter Query')
        # print find_similar_response(question_dict, answer_dict,question.lower())
        compare('cpu utilization is high', 'cpu utilize is high')
    except Exception, e:
        unique_logger.error('Exception occured.......')
        unique_logger.error('Exception Details.......%s', e)
