import sys
import os

cmd_new = '.'

#sys.path.append(cmd_new + '/')

import csv
import utils
from utils import nlpTask as nlp
from utils import fileOperations as fileOp
from utils import mongoDBOperations as mongo
import logging
import ConfigParser
import os
from config import *
# import longestMatch as match
import pandas as pd
# import fuzzy_match as fuzzy
import jaccard_index as jaccard
import time
from ConfigParser import SafeConfigParser
import os

date = time.strftime("%Y_%m_%d")
logger = logging.getLogger('Corpus')
logger.setLevel(logging.INFO)
logger_path=str(cmd_new + "/logs/personality_" + str(date) + ".log")
fh = logging.FileHandler(logger_path)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(funcName)2s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)

config = SafeConfigParser()
config.read(cmd_new + '/config/personalityConfig.cfg')


class PersonalityModel:
    fieldMaps = {}
    fieldNames = ['question_text', 'question_tokens', 'answer']
    modelDirectory = ''
    modelFileNames = {}
    categoryMaps = {}
    corpusMaps = {}
    questionKeys = {}
    categoryDataFrame = pd.DataFrame()
    fieldDataFrame = pd.DataFrame()
    questionDict = {}
    answerDict = {}
    questionList = []
    questionTokenList = []
    answerList = []
    vocab = []
    
    vocabFileName = config.get('COMMONFILES', 'VOCAB_FILENAME')

    @staticmethod
    def buildGenericModel(customerName):
        try:
            collectionName = 'Common'
            PersonalityModel.modelDirectory = cmd_new + '/data/' + customerName
            logger.info('Creating directory for customer {0} with name {1}'.format(customerName,
                                                                                   PersonalityModel.modelDirectory))
            if not os.path.exists(PersonalityModel.modelDirectory):
                os.makedirs(PersonalityModel.modelDirectory)
            PersonalityModel.categoryDataFrame = mongo.getDocumentContent(customerName, ['category'])
            data = mongo.getDocumentContent(collectionName, ['category'])
            categoryList = list(set(list(PersonalityModel.categoryDataFrame['category'])))
            for category in categoryList:
                PersonalityModel.fieldDataFrame = mongo.getDocumentContent(customerName, PersonalityModel.fieldNames)
                PersonalityModel.modelFileNames[
                    category] = PersonalityModel.modelDirectory + '/' + customerName + '_' + category + '_model.pkl'
                PersonalityModel.fieldDataFrame.to_pickle(PersonalityModel.modelFileNames[category])
                PersonalityModel.loadModel(customerName, category)

        except Exception, e:
            logger.error('Exception occured while creating generic model')
            logger.error('Exception details.......%s', e)

    @staticmethod
    def loadModel(customerName, category):

        try:
            logger.info('Loading personality model')
            modelDirectory = cmd_new + '/data/' + customerName
            modelFileName = modelDirectory + '/' + customerName + '_' + category + '_model.pkl'
            PersonalityModel.fieldDataFrame = pd.read_pickle(modelFileName)
            PersonalityModel.answerDict = dict(
                zip(PersonalityModel.fieldDataFrame['question_text'], PersonalityModel.fieldDataFrame['answer']))
            PersonalityModel.questionDict = dict(
                zip(PersonalityModel.fieldDataFrame['question_text'], PersonalityModel.fieldDataFrame['question_tokens']))
            PersonalityModel.questionList = PersonalityModel.questionDict.keys()
            PersonalityModel.answerList = PersonalityModel.answerDict.values()
            PersonalityModel.questionTokenList = PersonalityModel.questionDict.values()
            PersonalityModel.vocab = fileOp.read_txt_file(PersonalityModel.vocabFileName)
       

        except Exception, e:
            logger.error('Unable to load model for category.....{}'.format(category))
            logger.error('Exception details.....................{}'.format(e))

    def getRecommendation(self, customerName, inputQuery):
        try:
            jsonResponse = {}
            stemWords = []
            responseDict = {}
            responseList = []
            spellList = []
            category = 'Greetings'
            model_category = 'Common'
            if PersonalityModel.fieldDataFrame.empty:
                self.loadModel(model_category, category)
            processQuery = nlp.extract_word(nlp.punct_tokenize(inputQuery))
            spellList = nlp.spell_checker(processQuery, PersonalityModel.vocab)
            processQuery = nlp.word_stem(spellList)
            responses = jaccard.find_similar_response(self.questionList, self.questionTokenList, self.answerDict,
                                                      self.questionDict, processQuery)
            jsonResponse['query'] = inputQuery
            jsonResponse['customer_name'] = customerName
            for response in responses:
                responseDict['response'] = response[1]
                responseDict['confidence'] = response[2]
                responseList.append(responseDict)
                responseDict = {}
            jsonResponse['responses'] = responseList

            return jsonResponse

        except Exception, e:
            logger.error('Exception occured while getting recommendation for query %s for customer %s', inputQuery,
                         customerName)
            logger.error('Exception Details.......%s', e)

    def __init__(self, name):
        self.name = name
        self.question_dict = {}
        self.answer_dict = {}
        self.questions = []  # creates a new empty list for each dog


if __name__ == '__main__':
    PersonalityModel.buildGenericModel('Common')
