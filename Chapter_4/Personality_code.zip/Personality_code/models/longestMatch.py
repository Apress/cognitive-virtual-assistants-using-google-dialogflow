from collections import defaultdict
import random
import fileOperations as fileOp
import uniqueLogging
import time
import difflib
import operator
from random import shuffle
import os
import nlpTask as nlp
import random



unique_logger=uniqueLogging.unique_logging()

def find_similar_response(answerDict, questionList, question):
	similarity=[]
	summary_list=[]
	similarity={}
	result_tuple=[]
	resultDict={}
	questionResponse={}
        try: 	
		similarity_ref = difflib.SequenceMatcher(None)

		similarity_ref.set_seq2(question)
		for variation in questionList:
			similarity_ref.set_seq1(variation)
			similarity[variation]=similarity_ref.ratio()
    		result=sorted(similarity.items(), key=operator.itemgetter(1), reverse=True)[:5]
		if result[0][1]>0.80:
			result_tuple.append((question, random.choice(answerDict[result[0][0]]),result[0][1]))
			
		else:
			similarity={}
			for resultIndex in range(len(result)):
				keys=similarity.keys()
				max_score=0.0
				response=random.choice(answerDict[result[resultIndex][0]])
				question=result[resultIndex][0]
				score=result[resultIndex][1]
				if response not in keys:
					similarity[response]=score
					questionResponse[question]=score
				else:
					if score  > max_score:					
						similarity[response]=max_score
						questionResponse[question]=max_score
			similarity=sorted(similarity.items(),key=operator.itemgetter(1), reverse=True)
			questionResponse=sorted(questionResponse.items(),key=operator.itemgetter(1),reverse=True)
			for result in questionResponse:
				result_tuple.append((question,result[0],result[1]))
			'''for result in similarity:
				result_tuple.append((question,result[0], result[1]))'''
			



		return result_tuple

	except Exception ,e:
		unique_logger.error('Exception Occured.........')
		unique_logger.error('Exception Details........%s',e)

	
if __name__=='__main__':
	try:
		tin=time.time()
		question_filename='personality_question.pkl'
		answer_filename='personality_answer.pkl'
		question_dict=fileOp.read_pickle_file(question_filename)
		answer_dict=fileOp.read_pickle_file(answer_filename)
		while True:
			question=raw_input('Enter Query')
			print find_similar_response(question_dict, answer_dict,question.lower())
	except Exception,e:
		unique_logger.error('Exception occured.......')
		unique_logger.error('Exception Details.......%s',e)




