import csv
import logging
import pickle
import json
import time
import os

cmd_new = '.'

logger = logging.getLogger('fileOps')
logger.setLevel(logging.INFO)

date = time.strftime("%Y_%m_%d")
fh = logging.FileHandler(cmd_new + "/logs/personality_" + str(date) + ".log")
formatter = logging.Formatter('%(asctime)s - %(name)s - %(funcName)2s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)


def read_json_file(filename):
    try:
        logger.info('reading json file......')
        with open(filename, 'rb') as json_file:
            return json.load(json_file)


    except Exception, e:
        logger.error('Error occured while reading json file....')
        logger.error('Error details.......%s', e)


def write_json_file(filename, content):
    try:
        logger.info('writing json file.....')
        with open(filename, 'wb') as json_file:
            json.dump(json_file, content)


    except Exception, e:
        logger.error('Error occured while writing json file.....')
        logger.error('Error details.......%s', e)


def write_pickle_file(filename, content):
    try:
        logger.info('Writing dictionary to pickle file')
        data = open(filename, 'wb')
        pickle.dump(content, data)

    except Exception, e:
        logger.error('Error writing pickle file......')
        logger.error('Error details......%s', e)


def read_pickle_file(filename):
    try:
        logger.info('Reading pickle file....')
        with open(filename, 'rb') as data:
            return pickle.load(data)

    except Exception, e:
        logger.error('Error while reading data from pickle....')
        logger.error('Error details........%s', e)


def read_txt_file(filename):
    try:
        logger.info('Reading text file with name %s in binary.....', filename)
        with open(filename, 'rb') as data:
            file_data = data.read().splitlines()
        return file_data
    except Exception, e:
        logger.error('Exception Occurred.........')
        logger.error('Exception Details.........%s', e)
    finally:
        # logger.info('Closing File descriptor.........')
        data.close()


def write_txt_file(filename, content, mode='ab'):
    try:
        if mode == 'wb':
            with open(filename, 'wb') as data:
                data.write(content)
        else:
            with open(filename, 'ab') as data:
                data.write(content)
    except Exception, e:
        logger.error('Exception Occurred........')
        logger.error('Exception Details........%s', e)
    finally:
        data.close()


def write_list_txt_file(filename, content_list, mode='ab'):
    try:
        if mode == 'wb':
            logger.info('Writing content to file %s in mode %s', filename, mode)
            with open(filename, 'wb') as data:
                for content in content_list:
                    data.write(content + "\n")
        else:
            logger.info('Writing content to file %s in mode %s', filename, mode)
            with open(filename, 'ab') as data:
                for content in content_list:
                    data.write(content + "\n")
    except Exception, e:
        logger.error('Exception Occurred.......')
        logger.error('Exception Details........%s', e)
    finally:
        # logger.info('Closing File Descriptor......')
        data.close()


def write_csv_file(filename, content, mode='ab'):
    try:
        if mode == 'ab':
            with open(filename, 'ab') as data:
                data = csv.writer(data)
                data.writerow(content)
        else:
            with open(filename, 'wb') as data:
                data = csv.writer(data)
                data.writerow(content)

    except Exception, e:
        logger.error('Exception Occurred.........')
        logger.error('Exception Details.......%s', e)


def read_csv_file(filename, column_number):
    try:
        column_data = []
        with open(filename, 'rb') as data:
            data = csv.reader(data)
            for row in data:
                if row:
                    column_data.append(row[column_number - 1])
        return column_data
    except Exception, e:
        logger.error('Exception Occurred.........')
        logger.error('Exception Details..........%s', e)


if __name__ == '__main__':
    print read_csv_file('result.csv', 1)
