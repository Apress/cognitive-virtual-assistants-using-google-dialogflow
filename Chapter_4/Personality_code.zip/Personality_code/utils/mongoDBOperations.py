import pymongo
from pymongo import MongoClient
import json
from pymongo import DESCENDING
import sys
import logging
import ConfigParser
import fileOperations as fileOp
import nlpTask as nlp
from ConfigParser import SafeConfigParser
import pandas as pd
import re
from nltk.corpus import stopwords
import nltk
import time
import os

cmd_new = '.'

logger = logging.getLogger('MongoDBFunctions')
logger.setLevel(logging.INFO)
date = time.strftime("%Y_%m_%d")
fh = logging.FileHandler(cmd_new + "/logs/personality_" + str(date) + ".log")
formatter = logging.Formatter('%(asctime)s - %(name)s - %(funcName)2s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)

config = SafeConfigParser()
config.read(cmd_new + '/config/lucyConfig.cfg')


def dbConn():
    try:
        config = SafeConfigParser()
        config.read(cmd_new + '/config/lucyConfig.cfg')
        client = MongoClient(config.get('MongoDB', 'MONGODB_HOST'), int(config.get('MongoDB', 'MONGODB_PORT')))
        dbName = config.get('MongoDB', 'MONGODB_DB_NAME')
        # dbRef = client + '.{0}'.format(dbName)
        dbRef = client[dbName]
        return client, dbRef

    except Exception, e:
        logger.error('Unable to create connection to MongoDB')
        logger.error('Error details.......%s', e)
    finally:
        client.close()


def getCollectionNames():
    try:
        client, dbRef = dbConn()
        return dbRef.collection_names(include_system_collections=False)


    except Exception, e:
        logger.error('Unable to retreive collection name from MongoDB....')
        logger.error('Error details.......%s', e)


def insertDocument(collectionName, jsonDocs):
    try:
        client, dbRef = dbConn()
        db_collection = dbRef[collectionName]
        db_collection.insert(jsonDocs)

    except Exception, e:
        logger.error('Unable to insert document in collection %s', collectionName)
        logger.error('Error Details.............%s', e)
    finally:
        client.close()


def deleteDocument(collectionName, docID):
    try:
        dbRef = dbConn()
        db_collection = dbRef.collectionName
        db_collection.delete_many({"docID": docID})

    except Exception, e:
        logger.error('Unable to delete document from MongoDB for collection %s and docID %s', collectionName, docID)
        logger.error('Error Details..........%s', e)


def updateDoc(collectionName, docContent, docID):
    try:
        dbRef = dbConn()
        db_collection = dbRef.collectionName
        knowledge = question.questionAnswer(ticketSummary)
        for i in range(0, len(knowledge)):
            queryKey = {"ticketSummary": ticketSummary, "Url": knowledge[i]['Url']}
            updateData = {"ticketSummary": ticketSummary, "Url": knowledge[i]['Url'], "Title": knowledge[i]['Title'],
                          "Summary": knowledge[i]['Summary'], "Rating": knowledge[i]['Rating'],
                          "snapshotUrl": knowledge[i]['snapshotUrl']}
            db_collection.update(queryKey, {"$set": updateData}, upsert=True)
            queryKey = {}
            updateData = {}
    except Exception, e:
        logger.error('Unable to update dcument in collection %s for document %s in MongoDB', collectionName, docID)
        logger.error('Error details.....%s', e)


def getDocumentContent(collectionName, fieldNames):
    try:
        client, dbRef = dbConn()
        db_collection = dbRef[collectionName]
        jsonResponse = []
        fieldValues = {}
        for documentContent in db_collection.find():
            for field in fieldNames:
                if field not in fieldValues.keys():
                    fieldValues[field] = [documentContent[field]]
                else:
                    fieldValues[field].append(documentContent[field])
                    # print fieldValues['category']
                    # return fieldValues	
        return pd.DataFrame(fieldValues)

    except Exception, e:
        logger.error('Exception occured while retreiving document from collection with name.....%s', collectionName)
        logger.error('Error details......%s', e)


def clean_str(string):
    try:
        string = re.sub(r"[^A-Za-z0-9(),!?\'\`]", " ", string)
        string = re.sub(r"\'s", " \'s", string)
        string = re.sub(r"\'ve", " \'ve", string)
        string = re.sub(r"n\'t", " n\'t", string)
        string = re.sub(r"\'re", " \'re", string)
        string = re.sub(r"\'d", " \'d", string)
        string = re.sub(r"\'ll", " \'ll", string)
        string = re.sub(r",", " , ", string)
        string = re.sub(r"!", " ! ", string)
        string = re.sub(r"\(", " \( ", string)
        string = re.sub(r"\)", " \) ", string)
        string = re.sub(r"\?", " \? ", string)
        # string = re.sub(r"?","",string)
        string = re.sub(r"\s{2,}", " ", string)
        #print "string.....", string
        return string.strip().lower()
    except Exception, e:
        logger.error('Exception Occured.......')
        logger.error('Exception Details.......%s', e)


if __name__ == '__main__':
    inputFileName = config.get('COMMONFILES', 'INPUT_DATA_FILE')
    print inputFileName

    #	inputFileName='../personality_1.csv'
    question_list = fileOp.read_csv_file(inputFileName, 1)
    #print question_list
    answer_list = fileOp.read_csv_file(inputFileName, 2)
    stopword_list = nltk.corpus.stopwords.words('english')
    #print question_list
    #print answer_list
    jsonDocs = []
    questionTokens = []
    spellVocab = ['START']
    doc = {}
    spellVocabDict = {}
    questionDocs = {}
    count = 0
    # vocabFileName='/root/lucypersonality5/utils/vocab.txt'
    vocabFileName = config.get('COMMONFILES', 'VOCAB_FILENAME')
    for question, answer in zip(question_list, answer_list):
        processQuestion = clean_str(question).decode('ascii', 'ignore')
        if processQuestion not in questionDocs.keys():

            questionDocs[processQuestion] = [answer.decode('ascii', 'ignore')]
        else:
            questionDocs[processQuestion].append(answer)
        #	print questionDocs.keys()
    for key in questionDocs.keys():
        # print key
        questionTokens = nlp.extract_word(nlp.punct_tokenize(key))
        # print questionTokens
        questionStem = nlp.word_stem(questionTokens)
        spellVocab = spellVocab + questionTokens
        doc = {"question_text": key.lower(), "answer": (questionDocs[key]), "category": "Greetings",
               "question_tokens": questionStem}
        jsonDocs.append(doc)
        doc = {}
        # spellVocab=list(set(spellVocab))
    for word in spellVocab[1:]:
        if len(word) > 2:
            if word in spellVocabDict.keys():
                spellVocabDict[word] = spellVocabDict[word] + 1
            else:
                spellVocabDict[word] = 0

    for word in stopword_list:
        # if len(word)>2:
        spellVocabDict[word] = 0

    fileOp.write_list_txt_file(vocabFileName, spellVocabDict.keys(), 'wb')

    # print jsonDocs
    insertDocument('Common', jsonDocs)
    print ('done')
# print getDocumentContent('Generic', ['question_text', 'answer','question_tokens'])
