import nltk
import re
from nltk import word_tokenize
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from string import punctuation
from nltk.tokenize import wordpunct_tokenize
import logging
# import enchant
import time
import difflib
import operator
import os

cmd_new = '.'

logger = logging.getLogger('nlpTask')
logger.setLevel(logging.INFO)
date = time.strftime("%Y_%m_%d")
fh = logging.FileHandler(cmd_new + '/logs/personality_' + str(date) + ".log")
# fh = logging.FileHandler("iUnique.log")
formatter = logging.Formatter('%(asctime)s - %(name)s - %(funcName)2s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)


def punct_tokenize(summary):
    try:
        return wordpunct_tokenize(summary.lower().decode('utf-8', 'ignore'))
    except Exception, e:
        logger.error('Exception Occurred.......')
        logger.error('Exception Details.......%s', e)


def spell_checker(sentence, vocabulary=None):
    try:
        logger.info('validating sentence {} against spell checker'.format(sentence))
        spell_sentence = []
        sentence_stop = []
        spell_sentence_vocab = []
        lemma_sentence = []
        stop_correct_word = ''
        vocab_correct_word = ''
        stop_correct_word_score = 0
        vocab_correct_word_score = 0
        stopwords = set(nltk.corpus.stopwords.words('english') + list(punctuation))
        for token in sentence:
            stop_correct_word, stop_correct_score = similar_word(token, stopwords)
            vocab_correct_word, vocab_correct_score = similar_word(token, vocabulary)
            if vocab_correct_word_score >= stop_correct_word_score:
                spell_sentence.append(vocab_correct_word)
            else:
                spell_sentence.append(stop_correct_word)
        logger.info('correctly spelled sentence {0} for actual sentence {1}'.format(spell_sentence, sentence))
        return spell_sentence

    except Exception, e:
        logger.error('Exception Occurred..........')
        logger.error('Exception details...........%s', e)


def similar_word(token, spellwords):
    try:
        similarity = {}
        sim_matcher = difflib.SequenceMatcher(None)
        sim_matcher.set_seq2(token)
        for word in spellwords:
            sim_matcher.set_seq1(word)
            similarity[word] = sim_matcher.ratio()
        result = sorted(similarity.items(), key=operator.itemgetter(1), reverse=True)
        if result[0][1] >= 0.70:
            return result[0][0], result[0][1]
        else:
            return token, 0

    except Exception, e:
        logger.error('Exception Occurred.........')
        logger.error('Exception Details.........%s', e)


def remove_stopwords(tokens):
    try:
        stopwords = set(nltk.corpus.stopwords.words('english') + list(punctuation))
        filteredTokens = []
        symRemoval = []
        stem_word = []
        filteredTokens = [token for token in tokens if not token in stopwords]
        return filteredTokens
    except Exception, e:
        logger.error('Exception Occurred.......')
        logger.error('Exception Details.......%s', e)


def dict_word(tokens):
    try:
        processed_token = []
        d = enchant.Dict("en_US")
        for token in tokens:
            if d.check(token):
                processed_token.append(token)
        return processed_token
    except Exception, e:
        logger.error('Exception Occurred.......')
        logger.error('Exception Details........%s', e)


def extract_word(tokens):
    try:
        filteredWords = []
        for token in tokens:
            if re.search('^[a-zA-Z]+$', token):
                filteredWords.append(token)
        return filteredWords
    except Exception, e:
        logger.error('Exception Occurred.......')
        logger.error('Exception Details.......%s', e)


def word_stem(tokenList):
    try:
        # print tokenList
        stemmer = SnowballStemmer('english')
        stemmedTokens = [stemmer.stem(token) for token in tokenList]
        # print stemmedTokens
        return stemmedTokens
    except Exception, e:
        logger.error('Exception Occurred.......')
        logger.error('Exception Details.......%s', e)


if __name__ == '__main__':
    print similar_word('yo', ['you', 'yours', 'youn'])
